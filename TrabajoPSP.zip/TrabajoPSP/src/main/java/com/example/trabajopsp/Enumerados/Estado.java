package com.example.trabajopsp.Enumerados;

public enum Estado {
    DONE, WORK_IN_PROGRESS, TO_BE_DONE
}
